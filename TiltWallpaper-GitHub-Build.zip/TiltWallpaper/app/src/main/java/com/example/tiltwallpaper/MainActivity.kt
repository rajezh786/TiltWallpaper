package com.example.tiltwallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tilt_wallpaper", MODE_PRIVATE) }
    private val photos = mutableListOf<String>()
    private lateinit var countText: TextView
    private val pickPhotos = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        photos.addAll(prefs.getStringSet("photos", emptySet()).orEmpty().sorted())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 40, 28, 24)
        }
        root.addView(TextView(this).apply { text = "Tilt Wallpaper"; textSize = 28f; gravity = Gravity.CENTER; setPadding(0,0,0,18) })
        root.addView(TextView(this).apply {
            text = "Choose photos, then set this as your live wallpaper. Tilt your phone to move the image and switch between photos."
            textSize = 16f; gravity = Gravity.CENTER; setPadding(0,0,0,22)
        })
        countText = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(0,0,0,16) }
        root.addView(countText); refreshCount()
        root.addView(Button(this).apply { text = "Choose photos from Gallery"; setOnClickListener { chooseImages() } }, match())
        root.addView(TextView(this).apply { text = "Tilt sensitivity"; textSize = 16f; setPadding(0,20,0,0) })
        val sensitivity = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("sensitivity", 45)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { prefs.edit().putInt("sensitivity", progress.coerceAtLeast(5)).apply() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(sensitivity, match())
        root.addView(Button(this).apply { text = "Set Live Wallpaper"; setOnClickListener {
            if (photos.isEmpty()) Toast.makeText(this@MainActivity, "Please choose at least one photo", Toast.LENGTH_LONG).show()
            else try { startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this@MainActivity, TiltWallpaperService::class.java))) }
            catch (_: Exception) { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
        } }, match())
        root.addView(Button(this).apply { text = "Open Wallpaper Settings"; setOnClickListener { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } }, match())
        setContentView(root)
    }

    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 12 }
    private fun chooseImages() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        startActivityForResult(intent, pickPhotos)
    }
    @Deprecated("Deprecated Android callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickPhotos || resultCode != RESULT_OK || data == null) return
        val chosen = linkedSetOf<String>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) chosen.add(clip.getItemAt(i).uri.toString()) }
        data.data?.let { chosen.add(it.toString()) }
        chosen.forEach { raw -> try { contentResolver.takePersistableUriPermission(Uri.parse(raw), Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
        photos.clear(); photos.addAll(chosen)
        prefs.edit().putStringSet("photos", chosen).apply(); refreshCount()
        Toast.makeText(this, "${photos.size} photo(s) selected", Toast.LENGTH_SHORT).show()
    }
    private fun refreshCount() { countText.text = "Selected photos: ${photos.size}" }
}
