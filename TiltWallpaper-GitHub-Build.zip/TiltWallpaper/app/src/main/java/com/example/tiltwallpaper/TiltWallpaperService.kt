package com.example.tiltwallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class TiltWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = TiltEngine()

    inner class TiltEngine : Engine(), SensorEventListener {
        private val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var bitmap: Bitmap? = null
        private var photoUris = emptyList<String>()
        private var photoIndex = 0
        private var tiltX = 0f
        private var tiltY = 0f
        private var lastSwitch = 0L
        private var visible = false

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            if (visibleNow) { accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }; loadPhotos(); drawFrame() }
            else sensorManager.unregisterListener(this)
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { super.onSurfaceChanged(holder, format, width, height); drawFrame() }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) { visible = false; sensorManager.unregisterListener(this); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { sensorManager.unregisterListener(this); bitmap?.recycle(); bitmap = null; super.onDestroy() }

        private fun loadPhotos() {
            val prefs = getSharedPreferences("tilt_wallpaper", MODE_PRIVATE)
            photoUris = prefs.getStringSet("photos", emptySet()).orEmpty().sorted()
            if (photoUris.isEmpty()) { bitmap = null; return }
            photoIndex = photoIndex.coerceIn(0, photoUris.lastIndex)
            loadCurrent()
        }
        private fun loadCurrent() {
            if (photoUris.isEmpty()) return
            try {
                val uri = Uri.parse(photoUris[photoIndex])
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                val sample = max(1, max(opts.outWidth / 1600, opts.outHeight / 1600))
                val actual = BitmapFactory.Options().apply { inSampleSize = sample }
                val fresh = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, actual) }
                bitmap?.recycle(); bitmap = fresh
            } catch (_: Exception) { bitmap = null }
        }
        override fun onSensorChanged(event: SensorEvent) {
            val prefs = getSharedPreferences("tilt_wallpaper", MODE_PRIVATE)
            val sensitivity = prefs.getInt("sensitivity", 45).coerceAtLeast(5) / 45f
            val x = event.values[0] / 9.81f
            val y = event.values[1] / 9.81f
            tiltX = (x * sensitivity).coerceIn(-1.4f, 1.4f)
            tiltY = (y * sensitivity).coerceIn(-1.4f, 1.4f)
            val now = System.currentTimeMillis()
            if (photoUris.size > 1 && abs(x) > 0.72f && now - lastSwitch > 900) {
                photoIndex = (photoIndex + if (x > 0) 1 else photoUris.size - 1) % photoUris.size
                loadCurrent(); lastSwitch = now
            }
            drawFrame()
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        private fun drawFrame() {
            if (!visible) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    canvas.drawColor(Color.BLACK)
                    val bmp = bitmap
                    if (bmp != null && !bmp.isRecycled) {
                        val cw = canvas.width.toFloat(); val ch = canvas.height.toFloat()
                        val scale = max(cw / bmp.width, ch / bmp.height) * 1.18f
                        val dw = bmp.width * scale; val dh = bmp.height * scale
                        val maxX = max(0f, (dw - cw) / 2f); val maxY = max(0f, (dh - ch) / 2f)
                        val dx = ((dw - cw) / 2f + tiltX * maxX * 0.65f).coerceIn(0f, maxX * 2)
                        val dy = ((dh - ch) / 2f - tiltY * maxY * 0.45f).coerceIn(0f, maxY * 2)
                        canvas.drawBitmap(bmp, null, RectF(-dx, -dy, dw - dx, dh - dy), paint)
                    }
                }
            } catch (_: Exception) { } finally { if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
        }
    }
}
