# Tilt Wallpaper (Android source project)

A basic Android live-wallpaper project with gallery image selection, accelerometer parallax and tilt-triggered photo cycling.

## Build
Open this folder in Android Studio or AndroidIDE with internet access so Gradle can download Android Gradle Plugin 8.6.1 and Kotlin plugin 2.0.20. Sync, then Build > Build APK(s). Install the generated debug APK, open Tilt Wallpaper, choose photos, and tap Set Live Wallpaper.

This is source code, not a precompiled APK. The project has not been compiled or device-tested in this environment. Live wallpaper and sensor behavior can vary by Android vendor.
